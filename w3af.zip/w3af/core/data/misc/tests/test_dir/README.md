Do not remove. This directory is here for testing test_file_utils.py
